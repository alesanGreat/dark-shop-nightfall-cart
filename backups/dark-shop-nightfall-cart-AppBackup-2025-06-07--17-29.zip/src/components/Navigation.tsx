
import { ShoppingCart, Home, Info, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navigation = () => {
  return (
    <nav className="bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-foreground">Premium Store</h1>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              <a href="/" className="text-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2">
                <Home size={16} />
                Home
              </a>
              <a href="/cart" className="text-muted-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2">
                <ShoppingCart size={16} />
                Cart
              </a>
              <a href="/about" className="text-muted-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2">
                <Info size={16} />
                About
              </a>
              <a href="/contact" className="text-muted-foreground hover:text-primary px-3 py-2 rounded-md text-sm font-medium flex items-center gap-2">
                <Phone size={16} />
                Contact
              </a>
            </div>
          </div>
          
          <Button variant="outline" size="sm">
            <ShoppingCart size={16} className="mr-2" />
            Cart (0)
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
